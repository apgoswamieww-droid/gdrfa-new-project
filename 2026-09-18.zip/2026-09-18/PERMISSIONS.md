# Permissions Reference

Complete list of all permission slugs organized by module.

---

## Authentication

| Slug | Description |
|------|-------------|
| `can-login` | Can login to admin panel |
| `admin-access` | Admin panel access |

---

## Dashboard

| Slug | Description |
|------|-------------|
| `view-dashboard` | View dashboard |
| `view-latest-events` | View latest events widget |
| `view-latest-participants` | View latest participants widget |
| `view-total-employees` | View total employees stat |
| `view-total-events` | View total events stat |
| `view-total-managers` | View total managers stat |
| `view-total-participants` | View total participants stat |

---

## Masters — KPIs

| Slug | Description |
|------|-------------|
| `view-kpis` | View KPI list |
| `create-kpis` | Create new KPI |
| `edit-kpis` | Edit existing KPI |
| `delete-kpis` | Delete a KPI |
| `change-status-kpis` | Toggle KPI status |

---

## Masters — Event Types

| Slug | Description |
|------|-------------|
| `view-activity-type` | View event type list |
| `create-activity-type` | Create new event type |
| `edit-activity-type` | Edit existing event type |
| `delete-activity-type` | Delete an event type |
| `change-activity-type-status` | Toggle event type status |

---

## Masters — Event Activities

| Slug | Description |
|------|-------------|
| `view-sport-activity` | View event activity list |
| `create-sport-activity` | Create new event activity |
| `edit-sport-activity` | Edit existing event activity |
| `delete-sport-activity` | Delete an event activity |
| `change-sport-activity-status` | Toggle event activity status |
| `detail-view` | View event activity detail |

---

## Masters — Plans

| Slug | Description |
|------|-------------|
| `view-plans` | View plan list |
| `create-plan` | Create new plan |
| `edit-plan` | Edit existing plan |
| `delete-plan` | Delete a plan |
| `change-plan-status` | Toggle plan status |

---

## User Management — Admin Users

| Slug | Description |
|------|-------------|
| `list-view-admin` | View admin user list |
| `create-admin` | Create new admin user |
| `edit-admin` | Edit admin user |
| `delete-admin` | Delete admin user |
| `change-admin-status` | Toggle admin user status |

---

## User Management — Employees

| Slug | Description |
|------|-------------|
| `list-view-users` | View employee list |
| `create-users` | Create new employee |
| `edit-users` | Edit employee |
| `delete-users` | Delete employee |
| `change-user-status` | Toggle employee status |
| `user-view-details-page` | View employee detail page |
| `view-user-management` | View user management module |

---

## Teams

| Slug | Description |
|------|-------------|
| `view-team` | View team list |
| `create-team` | Create new team |
| `edit-team` | Edit existing team |
| `delete-team` | Delete a team |
| `change-team-status` | Toggle team status |
| `add-team-member` | Add member to team |

---

## Events

| Slug | Description |
|------|-------------|
| `view-event` | View event list |
| `create-event` | Create new event |
| `edit-event` | Edit existing event |
| `delete-event` | Delete an event |
| `change-event-status` | Toggle event status |
| `change-event-active-inactive` | Toggle event active/inactive |
| `can-event-end-or-complete` | Mark event as complete |
| `can-manage-activities` | Manage event activities |

---

## Participants

| Slug | Description |
|------|-------------|
| `view-list-participants` | View participant list |
| `view-details-of-participant` | View participant details |
| `change-status-of-participant` | Approve/reject participant |

---

## Evaluation

| Slug | Description |
|------|-------------|
| `view-evaluation-list` | View evaluation list |
| `view-evaluation` | View evaluation detail |
| `add-evaluation` | Add new evaluation |
| `edit-evaluation` | Edit existing evaluation |
| `delete-evaluation` | Delete an evaluation |
| `add-evaluation-rule` | Add evaluation rule |
| `edit-evaluation-rule` | Edit evaluation rule |
| `delete-evaluation-rule` | Delete evaluation rule |
| `change-evaluation-rule-status` | Toggle evaluation rule status |
| `view-evaluation-rule-list` | View evaluation rule list |

---

## Fitness Categories

| Slug | Description |
|------|-------------|
| `view-fitness-category-list` | View fitness category list |
| `add-fitness-category` | Create new fitness category |
| `edit-fitness-category` | Edit fitness category |
| `delete-fitness-category` | Delete fitness category |
| `change-fitness-category-status` | Toggle fitness category status |

---

## Facilities

| Slug | Description |
|------|-------------|
| `view-list-facilities` | View facility list |
| `create-facility` | Create new facility |
| `edit-facility` | Edit facility |
| `delete-facility` | Delete facility |
| `can-approve-or-reject-request` | Approve/reject facility request |
| `can-change-status` | Change status |

---

## FAQs

| Slug | Description |
|------|-------------|
| `view-faq-list` | View FAQ list |
| `create-faq` | Create new FAQ |
| `edit-faq` | Edit FAQ |
| `delete-faq` | Delete FAQ |
| `change-faq-status` | Toggle FAQ status |

---

## Sponsors

| Slug | Description |
|------|-------------|
| `view-sponsor-list` | View sponsor list |
| `create-sponsor` | Create new sponsor |
| `edit-sponsor` | Edit sponsor |
| `delete-sponsor` | Delete sponsor |

---

## Social Links

| Slug | Description |
|------|-------------|
| `view-social-link-list` | View social link list |
| `create-social-link` | Create new social link |
| `edit-social-link` | Edit social link |
| `delete-social-link` | Delete social link |

---

## Home Slider

| Slug | Description |
|------|-------------|
| `view-home-slider-list` | View home slider list |
| `create-home-slider` | Create new home slider |
| `edit-home-slider` | Edit home slider |
| `delete-home-slider` | Delete home slider |

---

## Blog

| Slug | Description |
|------|-------------|
| `view-blog-list` | View blog list |
| `create-blog` | Create new blog post |
| `edit-blog` | Edit blog post |
| `delete-blog` | Delete blog post |
| `change-status-blog` | Toggle blog status |

---

## Media

| Slug | Description |
|------|-------------|
| `view-media-list` | View media list |
| `create-media` | Upload new media |
| `edit-media` | Edit media |
| `delete-media` | Delete media |

---

## Contact Us

| Slug | Description |
|------|-------------|
| `view-contact-list` | View contact list |
| `create-contact` | Create contact entry |
| `delete-contact` | Delete contact entry |

---

## CMS Pages

| Slug | Description |
|------|-------------|
| `view-cms-page-list` | View CMS page list |
| `create-cms-page` | Create new CMS page |
| `edit-cms-page` | Edit CMS page |
| `delete-cms-page` | Delete CMS page |
| `change-cms-page-status` | Toggle CMS page status |

---

## Glimpse of Sports

| Slug | Description |
|------|-------------|
| `view-glimpse-list` | View glimpse of sports list |
| `create-glimpse` | Create new glimpse entry |
| `edit-glimpse` | Edit glimpse entry |
| `delete-glimpse` | Delete glimpse entry |

---

## Notifications

| Slug | Description |
|------|-------------|
| `view-notification-list` | View notifications |

---

## Audit History

| Slug | Description |
|------|-------------|
| `view-audit-history` | View audit history |

---

## Profile & Settings

| Slug | Description |
|------|-------------|
| `view-profile` | View profile |
| `edit-profile` | Edit profile |
| `change-password` | Change password |
| `view-settings` | View settings |
| `edit-settings` | Edit settings |

---

## Permissions Management

| Slug | Description |
|------|-------------|
| `view-permissions` | View permissions |
| `create-permissions` | Create permission |
| `edit-permissions` | Edit permission |
| `delete-permissions` | Delete permission |
| `change-permission-status` | Toggle permission status |

---

## Roles Management

| Slug | Description |
|------|-------------|
| `view-roles` | View roles |
| `create-roles` | Create role |
| `edit-roles` | Edit role |
| `delete-roles` | Delete role |

---

## Legacy / Reference Data (Used in Backend)

| Slug | Module |
|------|--------|
| `view-branches` | Branches |
| `create-branches` | Branches |
| `edit-branches` | Branches |
| `delete-branches` | Branches |
| `change-status-branch` | Branches |
| `view-departments` | Departments |
| `create-departments` | Departments |
| `edit-departments` | Departments |
| `delete-departments` | Departments |
| `change-status-department` | Departments |
| `view-sections` | Sections |
| `create-sections` | Sections |
| `edit-sections` | Sections |
| `delete-sections` | Sections |
| `change-sections-status` | Sections |
| `view-sectors` | Sectors |
| `create-sectors` | Sectors |
| `edit-sectors` | Sectors |
| `delete-sectors` | Sectors |
| `change-sector-status` | Sectors |
| `view-ranks` | Ranks |
| `create-ranks` | Ranks |
| `edit-ranks` | Ranks |
| `delete-ranks` | Ranks |
| `change-rank-status` | Ranks |
| `view-job-titles` | Job Titles |
| `create-job-titles` | Job Titles |
| `edit-job-titles` | Job Titles |
| `delete-job-titles` | Job Titles |
| `change-job-title-status` | Job Titles |
| `list-view-manager` | Managers |
| `create-manager` | Managers |
| `edit-manager` | Managers |
| `delete-manager` | Managers |
| `change-manager-status` | Managers |
| `view-staff-member` | Staff Members |
| `create-staff-member` | Staff Members |
| `edit-staff-member` | Staff Members |
| `delete-staff-member` | Staff Members |
| `change-staff-member-status` | Staff Members |
| `staff-detail-view` | Staff Members |
| `backup-database` | Database |
| `restore-database` | Database |
| `delete-database-backup` | Database |
| `view-database-settings` | Database |
| `webmaster-list-view` | Webmaster |

---

## Wildcard

| Slug | Description |
|------|-------------|
| `*` | SuperAdmin — grants all permissions |

---

## File References

| File | Purpose |
|------|---------|
| `Node/utils/permissionChecker.js` | Hardcoded permission list (dev) + CIAM API fetch (prod) |
| `Node/middlewares/checkPermission.js` | Slug-based permission middleware |
| `Admin/src/utils/routePermissions.ts` | Route-to-permission mapping for frontend |
| `Admin/src/component/Sidebar/sidebar.tsx` | Sidebar permission filtering |
| `Admin/src/context/AuthContext.tsx` | Auth context with permission helpers |
| `Admin/src/utils/permissions.ts` | Permission utility functions |
