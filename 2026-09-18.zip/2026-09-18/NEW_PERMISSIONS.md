# New Permission Slugs Added

31 new permission slugs added to `Node/utils/permissionChecker.js` for modules that previously used `master` (wildcard) or had no dedicated permissions.

---

## FAQs

| Slug | Description |
|------|-------------|
| `view-faq-list` | View FAQ list |
| `create-faq` | Create new FAQ |
| `edit-faq` | Edit FAQ |
| `delete-faq` | Delete FAQ |
| `change-faq-status` | Toggle FAQ status |

---

## Sponsors

| Slug | Description |
|------|-------------|
| `view-sponsor-list` | View sponsor list |
| `create-sponsor` | Create new sponsor |
| `edit-sponsor` | Edit sponsor |
| `delete-sponsor` | Delete sponsor |

---

## Social Links

| Slug | Description |
|------|-------------|
| `view-social-link-list` | View social link list |
| `create-social-link` | Create new social link |
| `edit-social-link` | Edit social link |
| `delete-social-link` | Delete social link |

---

## Home Slider

| Slug | Description |
|------|-------------|
| `view-home-slider-list` | View home slider list |
| `create-home-slider` | Create new home slider |
| `edit-home-slider` | Edit home slider |
| `delete-home-slider` | Delete home slider |

---

## Media

| Slug | Description |
|------|-------------|
| `view-media-list` | View media list |
| `create-media` | Upload new media |
| `edit-media` | Edit media |
| `delete-media` | Delete media |

---

## Contact Us

| Slug | Description |
|------|-------------|
| `view-contact-list` | View contact list |
| `create-contact` | Create contact entry |
| `delete-contact` | Delete contact entry |

---

## CMS Pages

| Slug | Description |
|------|-------------|
| `view-cms-page-list` | View CMS page list |
| `create-cms-page` | Create new CMS page |
| `edit-cms-page` | Edit CMS page |
| `delete-cms-page` | Delete CMS page |
| `change-cms-page-status` | Toggle CMS page status |

---

## Glimpse of Sports

| Slug | Description |
|------|-------------|
| `view-glimpse-list` | View glimpse of sports list |
| `create-glimpse` | Create new glimpse entry |
| `edit-glimpse` | Edit glimpse entry |
| `delete-glimpse` | Delete glimpse entry |

---

## Notifications

| Slug | Description |
|------|-------------|
| `view-notification-list` | View notifications |

---

## Quick Reference (All 31 Slugs)

```
view-faq-list, create-faq, edit-faq, delete-faq, change-faq-status
view-sponsor-list, create-sponsor, edit-sponsor, delete-sponsor
view-social-link-list, create-social-link, edit-social-link, delete-social-link
view-home-slider-list, create-home-slider, edit-home-slider, delete-home-slider
view-media-list, create-media, edit-media, delete-media
view-contact-list, create-contact, delete-contact
view-cms-page-list, create-cms-page, edit-cms-page, delete-cms-page, change-cms-page-status
view-glimpse-list, create-glimpse, edit-glimpse, delete-glimpse
view-notification-list
```
