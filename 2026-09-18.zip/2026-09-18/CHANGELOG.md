# GDRFA Permission System Refactor — Complete Changelog

**Date:** September 18, 2026
**Branch:** main
**Total Files Changed:** 65 files (+3,660 / -3,672 lines)

---

## Executive Summary

This refactor replaces the old `PERMISSIONS_BYPASS` and `authorizeResource` middleware with a simple slug-based `checkPermission` middleware. It adds role-based permission mapping, multi-role priority resolution, and mock user testing support for CIAM.

### Key Changes
1. **Removed** `PERMISSIONS_BYPASS` from 6 files
2. **Deleted** 4 obsolete middleware/utility files
3. **Created** `checkPermission.js` — new slug-based middleware
4. **Replaced** all ~138 `authorizeResource()` calls with `checkPermission()` using specific slugs
5. **Added** 31 new permission slugs for modules that previously used `master` wildcard
6. **Reorganized** hardcoded permissions by module with section comments
7. **Added** role-based permission mapping (SuperAdmin / Admin / Manager)
8. **Added** multi-role priority resolution for CIAM users with multiple roles
9. **Added** mock user testing support (3 test accounts with different roles)
10. **Fixed** Admin frontend route permissions and sidebar permissions
11. **Fixed** 7 critical slug mismatches between `permissionChecker.js` and `apiRoutes.js`/frontend

---

## Node Backend Changes

### New Files

| File | Purpose |
|------|---------|
| `Node/middlewares/checkPermission.js` | New slug-based permission middleware. Checks `req.user.permissions` for the required slug. SuperAdmin wildcard (`*`) grants all access. |

### Deleted Files

| File | Purpose |
|------|---------|
| `Node/middlewares/__tests__/resourceAuthorization.test.js` | Tests for the old resource authorization middleware |
| `Node/middlewares/permissionMiddleware.js` | Old permission middleware (unused) |
| `Node/middlewares/resourceAuthorization.js` | Old resource-based authorization (replaced by checkPermission) |
| `Node/utils/permissionsBypass.js` | Old permission bypass utility |

### Modified Files

#### `Node/utils/permissionChecker.js`
- **Added** `resolveHighestPriorityRole()` — picks highest-priority role when CIAM returns multiple roles
- **Added** `getAllPermissions()` — full CRUD permissions (~150 slugs) for Admin role
- **Added** `getManagerPermissions()` — limited permissions (~50 slugs) for Manager/Examiner role
- **Updated** `getUserPermissions()` — now uses role-based mapping: SuperAdmin → `['*']`, Admin → full, Manager → limited
- **Reorganized** all ~200 permission slugs by module with section comments
- **Added** 31 new slugs: FAQs (5), Sponsors (4), Social Links (4), Home Slider (4), Media (4), Contact Us (3), CMS Pages (5), Glimpse (4), Notifications (1)
- **Fixed** 5 slug name mismatches to match `apiRoutes.js`: `view-admin-list` → `list-view-admin`, `view-employees` → `list-view-users`, `view-participant-list` → `view-list-participants`, `create-evaluation` → `add-evaluation`, `create-fitness-category` → `add-fitness-category`
- **Added** 2 missing slugs: `change-status-of-participant`, `approve-event`
- **Removed** unused `db`, `axios`, `https` imports

#### `Node/ciam/ciam.service.js`
- **Added** `MOCK_USERS` map with 3 test accounts (superadmin@test.com, admin@test.com, manager@test.com)
- **Updated** `auth()` — checks mock user map first, returns `mockRoleId` directly for mock users
- **Updated** `getUserRoles()` — returns `mockRoleId` for mock users instead of encrypted roles
- **Updated** `getUserByDomainId()` — returns full user object for mock users

#### `Node/controllers/adminApi/adminAuthController.js`
- **Updated** `login()` — handles `mockRoleId` from CIAM mock users directly
- **Updated** `login()` — uses `resolveHighestPriorityRole()` instead of `decryptedPermissionArray[0]` for multi-role support
- **Removed** `PERMISSIONS_BYPASS` checks

#### `Node/middlewares/authMiddleware.js`
- **Updated** `verifyToken()` — handles `mockRoleId` from CIAM mock users directly
- **Updated** `verifyToken()` — uses `resolveHighestPriorityRole()` instead of `decryptedRoles?.[0]` for multi-role support
- **Removed** `PERMISSIONS_BYPASS` checks from `ensureAdminApiPermission()`

#### `Node/middlewares/verifySuperAdminOnly.js`
- **Removed** `PERMISSIONS_BYPASS` check

#### `Node/middlewares/verifyAdminOrSuperAdmin.js`
- **Removed** `PERMISSIONS_BYPASS` check

#### `Node/routes/apiRoutes.js`
- **Replaced** all ~138 `authorizeResource()` calls with `checkPermission()` using specific slugs
- **Removed** imports of deleted middleware files

#### `Node/controllers/adminApi/evaluationController.js`
- Updated to use slug-based permissions

#### `Node/controllers/adminApi/fitnessEvaluationController.js`
- Updated to use slug-based permissions

#### `Node/controllers/adminApi/participantController.js`
- Updated to use slug-based permissions

#### `Node/controllers/adminApi/teamController.js`
- Updated to use slug-based permissions

---

## Admin Frontend Changes

### Modified Files

#### `Admin/src/utils/routePermissions.ts`
- **Fixed** CMS module permissions (was all `view-blog-list`, now uses dedicated slugs)
- **Added** 8 missing route entries for: FAQs, Sponsors, Social Links, Home Slider, Media, Contact Us, CMS Pages, Glimpse

#### `Admin/src/component/Sidebar/sidebar.tsx`
- **Fixed** CMS sidebar permissions to use dedicated slugs
- **Added** `notifications` entry to `NAV_PERMISSIONS` map
- Uses `VITE_ADMINROLEID` and `VITE_SUPERADMINROLEID` for UI filtering

#### `Admin/src/context/AuthContext.tsx`
- Uses `VITE_ADMINROLEID` and `VITE_SUPERADMINROLEID` for `isAdminOrSuperAdmin()` check

#### `Admin/src/component/ProtectedRoute/ProtectedRoute.tsx`
- Uses `VITE_SUPERADMINROLEID` for route guard on `/cms/social-links`

#### `Admin/.env`
- **Removed** `VITE_PERMISSIONS_BYPASS`
- **Removed** `VITE_EVENTCOORDINATORROLEID` (dead variable, never used)
- **Removed** `VITE_MANAGERROLEID` (dead variable, never used)
- **Kept** `VITE_ADMINROLEID` and `VITE_SUPERADMINROLEID` (actively used)

#### Other Admin files updated
- `Admin/src/api/evaluation.api.ts`
- `Admin/src/api/fitnessEvaluation.api.ts`
- `Admin/src/api/participants.api.ts`
- `Admin/src/component/Topbar/topbar.tsx`
- `Admin/src/locales/translations.ts`
- `Admin/src/pages/AuditHistory/AuditHistory.tsx`
- `Admin/src/pages/Blog/CreateBlog.tsx`
- `Admin/src/pages/Blog/EditBlog.tsx`
- `Admin/src/pages/CmsPages/CmsPageModal.tsx`
- `Admin/src/pages/CmsPages/ManageCmsPages.tsx`
- `Admin/src/pages/CmsPages/ViewCmsPage.tsx`
- `Admin/src/pages/Dashboard/ProfileCard.tsx`
- `Admin/src/pages/EventActivities/EventActivityModal.tsx`
- `Admin/src/pages/EventTypes/EventTypeModal.tsx`
- `Admin/src/pages/Facilities/FacilitiesTable.tsx`
- `Admin/src/pages/Facilities/FacilityModal.tsx`
- `Admin/src/pages/Facilities/FacilityRequestsTable.tsx`
- `Admin/src/pages/FitnessEvaluation/FitnessEvaluationForm.tsx`
- `Admin/src/pages/FitnessEvaluation/FitnessEvaluationModal.tsx`
- `Admin/src/pages/FitnessEvaluation/FitnessEvaluationTable.tsx`
- `Admin/src/pages/FitnessEvaluation/ManageFitnessEvaluation.tsx`
- `Admin/src/pages/ManageContacts/ManageContacts.tsx`
- `Admin/src/pages/ManageContacts/ViewContact.tsx`
- `Admin/src/pages/ManageHomeSlider/HomeSliderModal.tsx`
- `Admin/src/pages/ManageKpi/KpiModal.tsx`
- `Admin/src/pages/ManageMedia/CreateMedia.tsx`
- `Admin/src/pages/ManageMedia/EditMedia.tsx`
- `Admin/src/pages/ManageMedia/ManageMedia.tsx`
- `Admin/src/pages/ManageMedia/MediaTable.tsx`
- `Admin/src/pages/ManageMedia/ViewMedia.tsx`
- `Admin/src/pages/ManageSponsor/SponsorModal.tsx`
- `Admin/src/pages/ManageTeam/ManageTeam.tsx`
- `Admin/src/pages/ManageTeam/TeamDetails.tsx`
- `Admin/src/pages/ManageTeam/TeamMembers.tsx`
- `Admin/src/pages/ManageTeam/TeamModal.tsx`
- `Admin/src/pages/Participants/Evaluation.tsx`
- `Admin/src/pages/Participants/ManageParticipants.tsx`
- `Admin/src/pages/Participants/ParticipantViewModal.tsx`
- `Admin/src/pages/Participants/ParticipantsTable.tsx`
- `Admin/src/pages/Participants/ViewParticipant.tsx`
- `Admin/src/pages/Plans/PlanModal.tsx`
- `Admin/src/pages/Profile/ProfilePage.tsx`

---

## Employee Frontend Changes

| File | Change |
|------|--------|
| `Employee/src/locales/i18n.ts` | Translation updates |
| `Employee/src/pages/Certificates/index.tsx` | Minor UI update |
| `Employee/src/pages/ContactUs.tsx` | Minor UI update |
| `Employee/src/pages/Home/FacilityDetail.tsx` | Minor UI update |

---

## Root Project Files

| File | Purpose |
|------|---------|
| `.gitignore` | Updated ignore rules |
| `PERMISSIONS.md` | New — Complete permissions reference (all ~200 slugs organized by module) |
| `NEW_PERMISSIONS.md` | New — List of 31 new permission slugs added |
| `CHANGELOG.md` | This file |

---

## Mock Testing Accounts

For role-based testing, login with:

| Email | Password | Role | Permissions |
|-------|----------|------|-------------|
| `superadmin@test.com` | `123456` | SuperAdmin | `['*']` — all access |
| `admin@test.com` | `123456` | Admin | Full CRUD (~146 slugs) |
| `manager@test.com` | `123456` | Manager/Examiner | Limited (~45 slugs) |

---

## Role Priority System

When CIAM returns multiple roles for a user, the system picks the highest-priority role:

```
SuperAdmin > Admin > Manager > EventCoordinator > Staff > User
```

Implemented in `Node/utils/permissionChecker.js` — `resolveHighestPriorityRole()`

---

## Permission Slugs by Module

| Module | Slugs |
|--------|-------|
| Auth/Login | `can-login`, `admin-access` |
| Dashboard | `view-dashboard`, `view-latest-events`, `view-latest-participants`, `view-total-employees`, `view-total-events`, `view-total-managers`, `view-total-participants` |
| KPIs | `view-kpis`, `create-kpis`, `edit-kpis`, `delete-kpis`, `change-status-kpis` |
| Event Types | `view-activity-type`, `create-activity-type`, `edit-activity-type`, `delete-activity-type`, `change-activity-type-status` |
| Event Activities | `view-sport-activity`, `create-sport-activity`, `edit-sport-activity`, `delete-sport-activity`, `change-sport-activity-status`, `detail-view` |
| Plans | `view-plans`, `create-plan`, `edit-plan`, `delete-plan`, `change-plan-status` |
| Admin Users | `list-view-admin`, `create-admin`, `edit-admin`, `delete-admin`, `change-admin-status` |
| Employees | `list-view-users`, `create-employee`, `edit-employee`, `delete-employee`, `change-employee-status`, `detail-employee`, `import-employees` |
| Teams | `view-teams`, `create-team`, `edit-team`, `delete-team`, `change-team-status`, `detail-team` |
| Events | `view-events`, `create-event`, `edit-event`, `delete-event`, `view-event-list`, `change-event-status`, `event-list-view`, `detail-event` |
| Participants | `view-list-participants`, `participant-list-view`, `create-participant`, `change-status-of-participant`, `approve-event` |
| Evaluation | `view-evaluation-list`, `add-evaluation`, `edit-evaluation`, `delete-evaluation`, `detail-view-evaluation`, `view-evaluation`, `can-approve-or-reject`, `evaluation-assign`, `evaluation-assignee`, `evaluation-assign-to-team` |
| Fitness | `view-fitness-category-list`, `add-fitness-category`, `edit-fitness-category`, `delete-fitness-category`, `change-fitness-category-status` |
| Facilities | `view-list-facilities`, `create-facility`, `edit-facility`, `delete-facility`, `can-approve-or-reject-request`, `can-change-status` |
| FAQs | `view-faq-list`, `create-faq`, `edit-faq`, `delete-faq`, `change-faq-status` |
| Sponsors | `view-sponsor-list`, `create-sponsor`, `edit-sponsor`, `delete-sponsor` |
| Social Links | `view-social-link-list`, `create-social-link`, `edit-social-link`, `delete-social-link` |
| Home Slider | `view-home-slider-list`, `create-home-slider`, `edit-home-slider`, `delete-home-slider` |
| Blog | `view-blog-list`, `create-blog`, `edit-blog`, `delete-blog`, `change-status-blog` |
| Media | `view-media-list`, `create-media`, `edit-media`, `delete-media` |
| Contact Us | `view-contact-list`, `create-contact`, `delete-contact` |
| CMS Pages | `view-cms-page-list`, `create-cms-page`, `edit-cms-page`, `delete-cms-page`, `change-cms-page-status` |
| Glimpse | `view-glimpse-list`, `create-glimpse`, `edit-glimpse`, `delete-glimpse` |
| Notifications | `view-notification-list` |
| Audit | `view-audit-history` |
| Profile/Settings | `view-profile`, `edit-profile`, `change-password`, `view-settings`, `edit-settings` |
| Permissions | `view-permissions`, `create-permissions`, `edit-permissions`, `delete-permissions`, `change-permission-status` |
| Roles | `view-roles`, `create-roles`, `edit-roles`, `delete-roles` |
| Legacy — Branches | `view-branches`, `create-branches`, `edit-branches`, `delete-branches`, `change-status-branch` |
| Legacy — Departments | `view-departments`, `create-departments`, `edit-departments`, `delete-departments`, `change-status-department` |
| Legacy — Sections | `view-sections`, `create-sections`, `edit-sections`, `delete-sections`, `change-sections-status` |
| Legacy — Sectors | `view-sectors`, `create-sectors`, `edit-sectors`, `delete-sectors`, `change-sector-status` |
| Legacy — Ranks | `view-ranks`, `create-ranks`, `edit-ranks`, `delete-ranks`, `change-rank-status` |
| Legacy — Job Titles | `view-job-titles`, `create-job-titles`, `edit-job-titles`, `delete-job-titles`, `change-job-title-status` |
| Legacy — Managers | `list-view-manager`, `create-manager`, `edit-manager`, `delete-manager`, `change-manager-status` |
| Legacy — Staff | `view-staff-member`, `create-staff-member`, `edit-staff-member`, `delete-staff-member`, `change-staff-member-status`, `staff-detail-view` |
| Database | `view-database-settings`, `backup-database`, `restore-database`, `delete-database-backup` |
| Webmaster | `webmaster-list-view` |
| Wildcard | `master` |

---

## Role-Based Permission Mapping

| Module | SuperAdmin | Admin | Manager |
|--------|:----------:|:-----:|:-------:|
| Dashboard | ✓ | ✓ | ✓ |
| KPIs | ✓ | ✓ | view only |
| Event Types | ✓ | ✓ | view only |
| Event Activities | ✓ | ✓ | view only |
| Plans | ✓ | ✓ | view only |
| Admin Users | ✓ | ✓ | ✗ |
| Employees | ✓ | ✓ | view only |
| Teams | ✓ | ✓ | ✓ |
| Events | ✓ | ✓ | ✓ |
| Participants | ✓ | ✓ | view + approve |
| Evaluation | ✓ | ✓ | ✗ |
| Fitness | ✓ | ✓ | ✗ |
| Facilities | ✓ | ✓ | ✓ |
| FAQs | ✓ | ✓ | view only |
| Sponsors | ✓ | ✓ | view only |
| Blog | ✓ | ✓ | view only |
| Media | ✓ | ✓ | view only |
| CMS Pages | ✓ | ✓ | view only |
| Contact Us | ✓ | ✓ | view only |
| Notifications | ✓ | ✓ | ✓ |
| Audit | ✓ | ✗ | ✗ |

---

## Slug Mismatch Fixes (Critical)

7 permission slug mismatches were found between `permissionChecker.js` and `apiRoutes.js`/frontend. These caused 403 errors for Admin and Manager roles on multiple modules.

### Renamed Slugs (5)

| Old Slug (in permissionChecker.js) | Correct Slug (in apiRoutes.js) | Module |
|---|---|---|
| `view-admin-list` | `list-view-admin` | Admin Users |
| `view-employees` | `list-view-users` | Employees |
| `view-participant-list` | `view-list-participants` | Participants |
| `create-evaluation` | `add-evaluation` | Evaluation |
| `create-fitness-category` | `add-fitness-category` | Fitness |

### Added Missing Slugs (2)

| Slug | Module | Was Missing From |
|---|---|---|
| `change-status-of-participant` | Participant Status Update | Both `getAllPermissions()` and `getManagerPermissions()` |
| `approve-event` | Event Approval | Both `getAllPermissions()` and `getManagerPermissions()` |

### Impact

| Before Fix | After Fix |
|---|---|
| Admin/Manager got 403 on Admin Users, Employees, Participants | All modules accessible |
| No one could create Evaluations/Fitness categories (except SuperAdmin) | Admin can create, Manager gets appropriate access |
| Event approval and participant status updates were SuperAdmin-only | Available to Admin and Manager roles |

---

## Production Safety Notes

1. **All mock changes are safe for production** — mock checks only activate for `@test.com` emails, all other users fall through to existing CIAM flow
2. **`mockRoleId` field** is only present in mock responses — production CIAM returns `encryptedRoles` which gets decrypted normally
3. **Permission mapping** uses `process.env.SUPERADMINROLEID` and `process.env.ADMINROLEID` — these must be set correctly in production `.env`
4. **Admin `.env` role IDs** (`VITE_ADMINROLEID`, `VITE_SUPERADMINROLEID`) are used only for frontend UI decisions (sidebar filtering, route guards) — not for permission enforcement
